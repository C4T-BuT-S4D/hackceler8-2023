<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="New Building Tiles" tilewidth="16" tileheight="16" tilecount="56" columns="7">
 <image source="tilemap_newtiles.png" width="112" height="128"/>
</tileset>
