<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="blue" tilewidth="64" tileheight="64" tilecount="1" columns="1">
 <image source="blue.png" width="64" height="64"/>
</tileset>
